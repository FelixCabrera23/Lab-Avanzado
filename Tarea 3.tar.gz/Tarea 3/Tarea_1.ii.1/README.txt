Aqui se debe compilar la tarea 1.ii.1

las instrucciónes son:

# para generar el make faile usar:
# $ cmake T_1.ii.1/

# Para generar el ejecutable usar
# $ make

# para ejecutar 
# $ ./tarea1.ii.1

