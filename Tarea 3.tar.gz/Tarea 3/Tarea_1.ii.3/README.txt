Aqui se debe compilar la tarea 1.ii.3

las instrucciónes son:

# para generar el make faile usar:
# $ cmake T_1.ii.3/

# Para generar el ejecutable usar
# $ make

# para ejecutar
# $ ./tarea1.ii.3


Esta la hice más complicada para probar solamente
